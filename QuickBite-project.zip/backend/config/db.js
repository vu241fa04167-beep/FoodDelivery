import mongoose from 'mongoose';

const connectDB = async () => {
  const primaryUri = process.env.MONGODB_URI;
  const localUri = 'mongodb://127.0.0.1:27017/quickbite';
  try {
    const conn = await mongoose.connect(primaryUri || localUri);
    console.log(`MongoDB Connected: ${conn.connection.host}`);
  } catch (error) {
    if (primaryUri && primaryUri !== localUri) {
      console.warn(`Primary MongoDB connection failed (${error.message}). Falling back to local MongoDB: ${localUri}`);
      try {
        const localConn = await mongoose.connect(localUri);
        console.log(`MongoDB Connected (local fallback): ${localConn.connection.host}`);
        return;
      } catch (localErr) {
        console.error(`Local MongoDB fallback error: ${localErr.message}`);
      }
    }
    console.error(`Database connection error: ${error.message}`);
    process.exit(1);
  }
};

export default connectDB;
